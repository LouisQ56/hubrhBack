package fr.onepoint.hubrh.dto;

import lombok.Data;

@Data
public class CollaborateurDto {
	private Integer id;
	
	private String name;
	private String firstname;
	private String email;

}