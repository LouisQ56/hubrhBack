INSERT INTO collaborateur
VALUES (0, 'Questel', 'Louis', 'l.questel@gmail.com', '2020-01-20 09:30:00',
		NULL, 'https://mycv.lol', FALSE, 1, 'Ce mec est super beau'),
VALUES (1, 'Loret', 'Alexis', 'l.questel@gmail.com', '2020-01-20 09:30:00',
		NULL, 'https://mycv.lol', FALSE, 1, 'Ce mec est super beau'),
VALUES (2, 'Pineau', 'Alexis', 'l.questel@gmail.com', '2020-01-20 09:30:00',
		NULL, 'https://mycv.lol', FALSE, 1, 'Ce mec est super beau');